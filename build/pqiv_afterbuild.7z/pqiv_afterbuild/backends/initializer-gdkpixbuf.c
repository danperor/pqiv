/* Auto-Generated file by Make. */
#include "../pqiv.h"
file_type_handler_t file_type_handlers[1 + 1];
void file_type_gdkpixbuf_initializer(file_type_handler_t *info);
void initialize_file_type_handlers(const gchar * const * disabled_backends) {
	int i = 0;
	if(!strv_contains(disabled_backends, "gdkpixbuf")) file_type_gdkpixbuf_initializer(&file_type_handlers[i++]);
}
